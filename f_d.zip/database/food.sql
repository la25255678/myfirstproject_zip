-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2023 at 04:00 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `food`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `con_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mesg` varchar(50) NOT NULL,
  PRIMARY KEY (`con_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`con_id`, `name`, `email`, `phone`, `mesg`) VALUES
(27, 'pyae phyo', 'pyae@gmail.com', '092782298729', 'THIS IS A DIMPLE PAGE'),
(28, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(50) NOT NULL,
  `prod_no` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `img`, `prod_no`, `price`) VALUES
(85, 'Char kuay teow.jpg', 'Char kuay teow', '(25000) MMK'),
(87, 'Laksa.jpg', 'Laksa', '(15000) MMK'),
(88, 'Nasi lemak.jpg', 'Nasi lemak', '(20000) MMK'),
(89, 'Chilli crab.jpg', 'Chilli crab', '(25000) MMK'),
(90, 'staya.jpg', 'staya', '(10000)MMK'),
(93, 'Kung-Pao-Chicken.jpg', 'Kung-Pao-Chicken', '(10000)MMK'),
(94, 'Steamed-Crab.jpg', 'Steamed-Crab', '(20000) MMK'),
(95, 'Shredded-pork-with-garlic-sauce.jpg', 'Shredded-pork-with-garlic-sauc', '(15000) MMK'),
(97, 'Red-braised-pork.jpg', 'Red-braised-pork', '(20000) MMK'),
(98, 'Beijing-hot-pot-.jpg', 'Beijing-hot-pot', '(30000)MMK'),
(99, '1. Spaghetti alla Carbonara.jpg', 'Spaghetti alla Carbonara', '(15000) MMK'),
(100, '5. Fiorentina Steak.jpg', 'Fiorentina Steak', '(15000) MMK'),
(101, '6. Polenta.jpg', ' Polenta', '(20000) MMK'),
(103, 'Sweet-and-sour-ribs.jpg', 'Sweet-and-sour-ribs', '(25000) MMK'),
(104, 'Twice-cooked-pork-slices.jpg', 'Twice-cooked-pork-slices', '(25000)MMK'),
(105, 'staya.jpg', 'Hokkien prawn mee', '(15000) MMK'),
(107, 'Shredded-pork-with-garlic-sauce.jpg', 'Lotus-root-and-rib-soup', '(20000) MMK'),
(108, 'Egg-fried-rice.jpg', 'Egg-fried-rice', '(15000) MMK'),
(109, 'Guilin-rice-noodles.jpg', 'Guilin-rice-noodles', '(15000) MMK'),
(111, 'Mapo-Tofu.jpg', 'Mapo-Tofu', '(20000) MMK');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ord_id` int(11) NOT NULL AUTO_INCREMENT,
  `productno` varchar(50) NOT NULL,
  `price` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `order_no` varchar(30) NOT NULL,
  PRIMARY KEY (`ord_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ord_id`, `productno`, `price`, `name`, `phone`, `address`, `order_no`) VALUES
(45, 'Laksa', '(15000) MMK', 'pyae phyo', '0029093440', '', 'ord474'),
(46, 'Laksa', '(15000) MMK', 'pyae phyo', '0029093440', '', 'ord214'),
(47, 'Laksa', '(15000) MMK', '', '', '', 'ord477'),
(48, 'Laksa', '(15000) MMK', 'pyae phyo', '0029093440', '', 'ord355');

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE IF NOT EXISTS `sign_up` (
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `township` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`first_name`, `last_name`, `email`, `password`, `phone_no`, `country`, `city`, `township`) VALUES
('pyae', 'phyo', 'pyae@gmail.com', '8799', '09028002', 'Myanmar', 'Yangon', 'Thamwe'),
('pyae', 'phyo', 'pyae@gmail.com', '8799', '09028002', 'Myanmar', 'Yangon', 'Thamwe');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `pass`) VALUES
('admin', '1234');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
